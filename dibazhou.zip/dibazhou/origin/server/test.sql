/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 50553
Source Host           : localhost:3306
Source Database       : test

Target Server Type    : MYSQL
Target Server Version : 50553
File Encoding         : 65001

Date: 2020-08-28 18:19:15
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for cart
-- ----------------------------
DROP TABLE IF EXISTS `cart`;
CREATE TABLE `cart` (
  `cart_id` int(50) NOT NULL,
  `good_id` int(50) NOT NULL,
  `user_id` int(50) NOT NULL,
  `num` int(50) NOT NULL,
  PRIMARY KEY (`cart_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- ----------------------------
-- Records of cart
-- ----------------------------

-- ----------------------------
-- Table structure for goods
-- ----------------------------
DROP TABLE IF EXISTS `goods`;
CREATE TABLE `goods` (
  `goods_id` int(10) NOT NULL AUTO_INCREMENT,
  `src` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `name` varchar(255) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  `price` varchar(50) CHARACTER SET utf8 COLLATE utf8_bin DEFAULT NULL,
  PRIMARY KEY (`goods_id`)
) ENGINE=MyISAM AUTO_INCREMENT=141 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of goods
-- ----------------------------
INSERT INTO `goods` VALUES ('1', 'https://cdn.cnbj0.fds.api.mi-img.com/b2c-shopapi-pms/pms_1596796216.78257963.png', '日出而作系列-全镂空陀飞轮机械表 尊雅黑', '6499元 6699元');
INSERT INTO `goods` VALUES ('2', 'https://cdn.cnbj0.fds.api.mi-img.com/b2c-shopapi-pms/pms_1590651228.58065372.jpg', '厨房安全监控套装', '477元');
INSERT INTO `goods` VALUES ('3', 'https://cdn.cnbj0.fds.api.mi-img.com/b2c-shopapi-pms/pms_1569691861.38973660.jpg', '小米全面屏电视65英寸 E65C 灰色', '2699元 3099元');
INSERT INTO `goods` VALUES ('4', 'https://cdn.cnbj1.fds.api.mi-img.com/mi-mall/e2ab66a8c986a8e0dbb85c432fc0cd84.jpg', '小米全面屏电视 43英寸 E43C 黑色', '1099元 1499元');
INSERT INTO `goods` VALUES ('5', 'https://cdn.cnbj0.fds.api.mi-img.com/b2c-shopapi-pms/pms_1589855374.71192668.jpg', '小米全面屏电视43英寸 E43K 黑色', '999元 1099元');
INSERT INTO `goods` VALUES ('6', 'https://cdn.cnbj0.fds.api.mi-img.com/b2c-shopapi-pms/pms_1570600947.92372088.jpg', '小米全面屏电视 55英寸E55X 灰色', '1799元 1999元');
INSERT INTO `goods` VALUES ('7', 'https://cdn.cnbj0.fds.api.mi-img.com/b2c-shopapi-pms/pms_1569249648.53373412.jpg', '全面屏电视Pro 55英寸 E55S', '2399元');
INSERT INTO `goods` VALUES ('8', 'https://cdn.cnbj1.fds.api.mi-img.com/mi-mall/1fa6b7e80b1acc6fc48ed263e65ccf5a.jpg', '小米全面屏电视43英寸 E43X 灰色', '1099元 1499元');
INSERT INTO `goods` VALUES ('9', 'https://cdn.cnbj0.fds.api.mi-img.com/b2c-shopapi-pms/pms_1569287693.9871682.jpg', '全面屏电视Pro 43英寸 E43S', '1499元');
INSERT INTO `goods` VALUES ('10', 'https://cdn.cnbj0.fds.api.mi-img.com/b2c-shopapi-pms/pms_1569287811.46782023.jpg', '全面屏电视Pro 65英寸 E65S', '3399元');
INSERT INTO `goods` VALUES ('11', 'https://cdn.cnbj0.fds.api.mi-img.com/b2c-shopapi-pms/pms_1590207082.40799227.jpg', '全面屏电视Pro 32英寸 E32S', '799元 899元');
INSERT INTO `goods` VALUES ('12', 'https://cdn.cnbj1.fds.api.mi-img.com/mi-mall/65adc10bf3a28d6dee6a912bbd23ce34.jpg', '全面屏电视Pro 75英寸 E75S', '4999元 5999元');
INSERT INTO `goods` VALUES ('13', 'https://cdn.cnbj0.fds.api.mi-img.com/b2c-shopapi-pms/pms_1562137966.77456698.jpg', '小米全面屏电视E55C 灰色', '1799元 1999元');
INSERT INTO `goods` VALUES ('14', 'https://cdn.cnbj0.fds.api.mi-img.com/b2c-shopapi-pms/pms_1562138486.16379871.jpg', '小米全面屏电视E55A 灰色', '1799元 1999元');
INSERT INTO `goods` VALUES ('15', 'https://cdn.cnbj0.fds.api.mi-img.com/b2c-shopapi-pms/pms_1562135572.19265027.jpg', '小米全面屏电视E32A 灰色', '799元 899元');
INSERT INTO `goods` VALUES ('16', 'https://cdn.cnbj0.fds.api.mi-img.com/b2c-shopapi-pms/pms_1562139940.61798032.jpg', '小米全面屏电视E65A 灰色', '2699元 3099元');
INSERT INTO `goods` VALUES ('17', 'https://cdn.cnbj0.fds.api.mi-img.com/b2c-shopapi-pms/pms_1562136966.41918063.jpg', '小米全面屏电视E43A 灰色', '1099元 1499元');
INSERT INTO `goods` VALUES ('18', 'https://cdn.cnbj0.fds.api.mi-img.com/b2c-shopapi-pms/pms_1561540340.2381311.jpg', '小米全面屏电视E40A 黑色', '1099元 1399元');
INSERT INTO `goods` VALUES ('19', 'https://cdn.cnbj0.fds.api.mi-img.com/b2c-shopapi-pms/pms_1559013725.88313357.png', '小米电视55英寸全面屏PRO 灰色', '2499元 3899元');
INSERT INTO `goods` VALUES ('20', 'https://cdn.cnbj0.fds.api.mi-img.com/b2c-shopapi-pms/pms_1559014117.09888499.jpg', '小米电视65英寸全面屏PRO 灰色', '3999元 6299元');
INSERT INTO `goods` VALUES ('121', 'https://cdn.cnbj0.fds.api.mi-img.com/b2c-shopapi-pms/pms_1560230039.28979252.jpg', '小米小爱音箱 Play', '99元 169元');
INSERT INTO `goods` VALUES ('122', 'https://cdn.cnbj0.fds.api.mi-img.com/b2c-shopapi-pms/pms_1568617574.69725219.jpg', '小米小爱音箱 Pro', '299元');
INSERT INTO `goods` VALUES ('123', 'https://cdn.cnbj0.fds.api.mi-img.com/b2c-shopapi-pms/pms_1575427252.04796744.jpg', 'Redmi小爱音箱 Play 白色', '79元');
INSERT INTO `goods` VALUES ('124', 'https://cdn.cnbj0.fds.api.mi-img.com/b2c-shopapi-pms/pms_1590029408.70095421.jpg', '小米小爱音箱 Art 白色', '349元');
INSERT INTO `goods` VALUES ('125', 'https://cdn.cnbj0.fds.api.mi-img.com/b2c-shopapi-pms/pms_1567593445.06061442.jpg', '小米小爱音箱 Play+米家台灯1S套装', '278元 348元');
INSERT INTO `goods` VALUES ('126', 'https://cdn.cnbj0.fds.api.mi-img.com/b2c-shopapi-pms/pms_1589879498.99952594.jpg', 'Redmi 电视条形音箱 黑色', '199元');
INSERT INTO `goods` VALUES ('127', 'https://cdn.cnbj0.fds.api.mi-img.com/b2c-shopapi-pms/pms_1593339346.09992308.jpg', '小米小爱随身音箱 白色', '49元');
INSERT INTO `goods` VALUES ('128', 'https://cdn.cnbj0.fds.api.mi-img.com/b2c-shopapi-pms/pms_1550719656.70567332.jpg', '小米小爱触屏音箱 白色', '199元');
INSERT INTO `goods` VALUES ('129', 'https://cdn.cnbj0.fds.api.mi-img.com/b2c-shopapi-pms/pms_1568616753.58243142.jpg', '小米小爱音箱 白色', '249元 269元');
INSERT INTO `goods` VALUES ('130', 'https://cdn.cnbj0.fds.api.mi-img.com/b2c-shopapi-pms/pms_1573031970.47458207.jpg', '小米随身蓝牙音箱 无线立体声2个装 黑色', '129元');
INSERT INTO `goods` VALUES ('131', 'https://cdn.cnbj0.fds.api.mi-img.com/b2c-shopapi-pms/pms_1578377349.02333205.jpg', '小米随身蓝牙音箱 灰', '69元');
INSERT INTO `goods` VALUES ('132', 'https://cdn.cnbj0.fds.api.mi-img.com/b2c-shopapi-pms/pms_1567480714.19846959.jpg', '小爱音箱 Play+米家飞利浦彩光灯泡套装', '168元 238元');
INSERT INTO `goods` VALUES ('133', 'https://cdn.cnbj0.fds.api.mi-img.com/b2c-shopapi-pms/pms_1584930592.94895287.jpg', 'Redmi小爱触屏音箱 8', '349元');
INSERT INTO `goods` VALUES ('134', 'https://cdn.cnbj0.fds.api.mi-img.com/b2c-shopapi-pms/pms_1569296497.06566845.jpg', '小米户外蓝牙音箱 深灰色', '169元 199元');
INSERT INTO `goods` VALUES ('135', 'https://cdn.cnbj0.fds.api.mi-img.com/b2c-shopapi-pms/pms_1590295912.74284920.jpg', '氧器重低音蓝牙音箱 黑色', '1299元');
INSERT INTO `goods` VALUES ('136', 'https://cdn.cnbj0.fds.api.mi-img.com/b2c-shopapi-pms/pms_1577953824.77871917.jpg', '小米户外蓝牙音箱 mini 黑色', '99元');
INSERT INTO `goods` VALUES ('137', 'https://cdn.cnbj1.fds.api.mi-img.com/mi-mall/8c52f60113b2e235544abca95d6687f4.jpg', '小米小爱触屏音箱Pro 8', '599元');
INSERT INTO `goods` VALUES ('138', 'https://cdn.cnbj1.fds.api.mi-img.com/mi-mall/83e6e1d81dbf65cfcddcbfcfcbfefc8d.png', '小爱音箱万能遥控版 超级通话版', '399元');
INSERT INTO `goods` VALUES ('139', 'https://cdn.cnbj0.fds.api.mi-img.com/b2c-shopapi-pms/pms_1581411694.79656473.jpg', '小米无线充蓝牙音箱 白色', '199元 249元');
INSERT INTO `goods` VALUES ('140', 'https://cdn.cnbj0.fds.api.mi-img.com/b2c-miapp-a1/17a13755-6212-7275-e573-cc1ea9fa2ae4.jpg', '小米方盒子蓝牙音箱 2 白色', '129元');

-- ----------------------------
-- Table structure for user
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `user_id` int(50) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) NOT NULL DEFAULT '',
  `password` varchar(50) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES ('1', 'zss', '123');
